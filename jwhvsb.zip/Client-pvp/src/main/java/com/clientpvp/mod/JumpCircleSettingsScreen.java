package com.clientpvp.mod;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.gui.widget.button.CheckboxButton;
import net.minecraft.client.gui.widget.AbstractSlider;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.StringTextComponent;

public class JumpCircleSettingsScreen extends Screen {
    private final Screen parent;

    protected JumpCircleSettingsScreen(Screen parent) {
        super(new StringTextComponent("Jump Circles Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 150;
        int top = this.height / 2 - 95;

        addButton(new Button(left + 12, top + 24, 130, 20,
                new StringTextComponent("Style: " + ModController.getJumpStyleName()), b -> {
            ModController.cycleStyle();
            b.setMessage(new StringTextComponent("Style: " + ModController.getJumpStyleName()));
        }));

        addButton(new CheckboxButton(left + 158, top + 24, 130, 20,
                new StringTextComponent("Random style"), ModController.isJumpRandomStyle()) {
            @Override
            public void onPress() {
                super.onPress();
                ModController.setJumpRandomStyle(this.selected());
            }
        });

        addButton(new CheckboxButton(left + 12, top + 50, 130, 20,
                new StringTextComponent("Smooth alpha"), ModController.isJumpEaseAlpha()) {
            @Override
            public void onPress() {
                super.onPress();
                ModController.setJumpEaseAlpha(this.selected());
            }
        });

        addButton(new CheckboxButton(left + 158, top + 50, 130, 20,
                new StringTextComponent("Enable circles"), ModController.isJumpCirclesEnabled()) {
            @Override
            public void onPress() {
                super.onPress();
                ModController.setJumpCirclesEnabled(this.selected());
            }
        });

        addButton(new ValueSlider(left + 12, top + 82, 276, 20, "Scale", 0.5, 4.0, ModController.getJumpScale()) {
            @Override
            protected void applyValue(double value) {
                ModController.setJumpScale((float) value);
            }
        });

        addButton(new ValueSlider(left + 12, top + 106, 276, 20, "Lifetime", 40.0, 240.0, ModController.getJumpLife()) {
            @Override
            protected void applyValue(double value) {
                ModController.setJumpLife((int) Math.round(value));
            }

            @Override
            protected String formatValue(double value) {
                return Integer.toString((int) Math.round(value));
            }
        });

        addButton(new ValueSlider(left + 12, top + 130, 276, 20, "Spin", 0.0, 4.0, ModController.getJumpSpinSpeed()) {
            @Override
            protected void applyValue(double value) {
                ModController.setJumpSpin((float) value);
            }
        });

        addButton(new Button(left + 12, top + 158, 276, 20, new StringTextComponent("Back"), b -> this.minecraft.setScreen(parent)));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(MatrixStack stack, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(stack);
        int left = this.width / 2 - 150;
        int top = this.height / 2 - 95;
        fill(stack, left, top, left + 300, top + 185, 0xD0111418);
        fill(stack, left, top, left + 300, top + 20, 0xD0202A32);
        drawCenteredString(stack, this.font, "Jump Circles Settings", this.width / 2, top + 6, 0x77E6FF);
        super.render(stack, mouseX, mouseY, partialTicks);
    }

    private abstract static class ValueSlider extends AbstractSlider {
        private final String label;
        private final double min;
        private final double max;

        protected ValueSlider(int x, int y, int width, int height, String label, double min, double max, double current) {
            super(x, y, width, height, StringTextComponent.EMPTY, normalize(current, min, max));
            this.label = label;
            this.min = min;
            this.max = max;
            updateMessage();
        }

        private static double normalize(double value, double min, double max) {
            return MathHelper.clamp((value - min) / (max - min), 0.0, 1.0);
        }

        private double denormalize() {
            return min + (max - min) * this.value;
        }

        @Override
        protected void updateMessage() {
            setMessage(new StringTextComponent(label + ": " + formatValue(denormalize())));
        }

        protected String formatValue(double value) {
            return String.format("%.2f", value);
        }

        @Override
        protected void applyValue() {
            applyValue(denormalize());
        }

        protected abstract void applyValue(double value);
    }
}
