package com.clientpvp.mod;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.OptionsScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.WorldSelectionScreen;
import net.minecraft.client.gui.screen.MultiplayerScreen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;

public class CustomMainMenuScreen extends Screen {
    public CustomMainMenuScreen() { super(new StringTextComponent("ClientPVP")); }

    @Override
    protected void init() {
        int cx = this.width / 2 - 100;
        int y = this.height / 2 - 50;
        addButton(new Button(cx, y, 200, 20, new StringTextComponent("Singleplayer"), b -> minecraft.setScreen(new WorldSelectionScreen(this))));
        addButton(new Button(cx, y + 24, 200, 20, new StringTextComponent("Multiplayer"), b -> minecraft.setScreen(new MultiplayerScreen(this))));
        addButton(new Button(cx, y + 48, 200, 20, new StringTextComponent("Alt Manager"), b -> minecraft.setScreen(new AltManagerScreen(this))));
        addButton(new Button(cx, y + 72, 98, 20, new StringTextComponent("Options"), b -> minecraft.setScreen(new OptionsScreen(this, minecraft.options))));
        addButton(new Button(cx + 102, y + 72, 98, 20, new StringTextComponent("Quit"), b -> minecraft.stop()));
    }

    @Override
    public void render(MatrixStack stack, int mouseX, int mouseY, float partialTicks) {
        fill(stack, 0, 0, this.width, this.height, 0xFF0A0E14);
        drawCenteredString(stack, this.font, "CLIENTPVP", this.width / 2, 32, 0x66E3FF);
        drawCenteredString(stack, this.font, "Forge 1.16.5 Custom Main Menu", this.width / 2, 48, 0xB0B8C2);
        super.render(stack, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
