package com.clientpvp.mod;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.IngameMenuScreen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector3f;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import java.util.*;

public class ModController {
    public enum BindAction { OPEN_GUI, TOGGLE_JUMP_CIRCLES, TOGGLE_AUTOSPRINT, TOGGLE_AIMASSIST, TOGGLE_JUMPRESET }

    private static final ResourceLocation[] STYLES = new ResourceLocation[]{
            new ResourceLocation(ClientPvpMod.MOD_ID, "textures/jump_circles/circle_unblack.png"),
            new ResourceLocation(ClientPvpMod.MOD_ID, "textures/jump_circles/portal_unblack.png"),
            new ResourceLocation(ClientPvpMod.MOD_ID, "textures/jump_circles/hexagon_unblack.png"),
            new ResourceLocation(ClientPvpMod.MOD_ID, "textures/jump_circles/circle_bold_unblack.png")
    };

    private static final EnumMap<BindAction, Integer> BINDS = new EnumMap<>(BindAction.class);
    private static BindAction pendingBind = null;

    static {
        BINDS.put(BindAction.OPEN_GUI, GLFW.GLFW_KEY_RIGHT_SHIFT);
        BINDS.put(BindAction.TOGGLE_JUMP_CIRCLES, GLFW.GLFW_KEY_UNKNOWN);
        BINDS.put(BindAction.TOGGLE_AUTOSPRINT, GLFW.GLFW_KEY_UNKNOWN);
        BINDS.put(BindAction.TOGGLE_AIMASSIST, GLFW.GLFW_KEY_UNKNOWN);
        BINDS.put(BindAction.TOGGLE_JUMPRESET, GLFW.GLFW_KEY_UNKNOWN);
    }

    private static boolean jumpCirclesEnabled = true, autoSprintEnabled = true, aimAssistEnabled = false, jumpResetEnabled = false;
    private static float aimAssistRange = 4.0f, aimAssistFov = 35f, aimAssistStrength = 3.0f;
    private static int aimAssistHoldKey = GLFW.GLFW_KEY_LEFT_ALT;
    private static int jumpStyle = 0, jumpLife = 140;
    private static float jumpScale = 1.5f, jumpSpinSpeed = 0.6f;
    private static boolean wasJumpKeyDown = false, wasHurt = false, jumpRandomStyle = false, jumpEaseAlpha = true;
    private static final List<JumpCircle> CIRCLES = new ArrayList<>();
    private static final Random RNG = new Random();

    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent e) {
        if (e.getGui() != null && e.getGui().getClass().getName().equals("net.minecraft.client.gui.screen.MainMenuScreen")) e.setGui(new CustomMainMenuScreen());
    }

    @SubscribeEvent
    public void onPauseInit(GuiScreenEvent.InitGuiEvent.Post e) {
        if (e.getGui() instanceof IngameMenuScreen) {
            e.addWidget(new Button(e.getGui().width - 106, 6, 100, 20, new net.minecraft.util.text.StringTextComponent("ClientPVP Binds"), b -> Minecraft.getInstance().setScreen(new BindManagerScreen(e.getGui()))));
        }
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent e) {
        if (e.getAction() != GLFW.GLFW_PRESS) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof ChatScreen) return;

        if (pendingBind != null) return; // capture only in BindManagerScreen keyPressed

        if (mc.screen != null) return;
        int key = e.getKey();
        if (key == BINDS.get(BindAction.OPEN_GUI)) {
            if (mc.screen instanceof ClickGuiScreen) mc.setScreen(null); else mc.setScreen(new ClickGuiScreen());
            return;
        }
        if (key == BINDS.get(BindAction.TOGGLE_JUMP_CIRCLES)) jumpCirclesEnabled = !jumpCirclesEnabled;
        if (key == BINDS.get(BindAction.TOGGLE_AUTOSPRINT)) autoSprintEnabled = !autoSprintEnabled;
        if (key == BINDS.get(BindAction.TOGGLE_AIMASSIST)) aimAssistEnabled = !aimAssistEnabled;
        if (key == BINDS.get(BindAction.TOGGLE_JUMPRESET)) jumpResetEnabled = !jumpResetEnabled;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientPlayerEntity p = mc.player; if (p == null || mc.level == null) return;

        if (autoSprintEnabled && !p.isSprinting() && p.input != null && p.input.up && p.getFoodData().getFoodLevel() > 6) p.setSprinting(true);
        if (jumpResetEnabled) { boolean hurt = p.hurtTime > 0; if (hurt && !wasHurt && p.isOnGround()) p.jumpFromGround(); wasHurt = hurt; }

        boolean aimHold = GLFW.glfwGetKey(mc.getWindow().getWindow(), aimAssistHoldKey) == GLFW.GLFW_PRESS;
        if (aimAssistEnabled && aimHold) applyAimAssist(mc, p);

        boolean jumpKey = p.input != null && p.input.jumping;
        if (jumpCirclesEnabled && jumpKey && !wasJumpKeyDown && p.isOnGround()) CIRCLES.add(new JumpCircle(p.getX(), p.getY()+0.02, p.getZ(), jumpScale, jumpLife, jumpRandomStyle?RNG.nextInt(STYLES.length):jumpStyle, jumpSpinSpeed));
        wasJumpKeyDown = jumpKey;

        CIRCLES.removeIf(c -> { c.tick(); return c.age >= c.maxLife; });
    }

    private static void applyAimAssist(Minecraft mc, ClientPlayerEntity p) {
        PlayerEntity best = null; double bestScore = 9999;
        for (PlayerEntity t : mc.level.getEntitiesOfClass(PlayerEntity.class, p.getBoundingBox().inflate(aimAssistRange))) {
            if (t == p || !t.isAlive()) continue;
            double dist = p.distanceTo(t); if (dist > aimAssistRange) continue;
            float yawTo = (float)(MathHelper.atan2(t.getZ()-p.getZ(), t.getX()-p.getX()) * (180f/Math.PI)) - 90f;
            float yawDelta = Math.abs(MathHelper.wrapDegrees(yawTo - p.yRot)); if (yawDelta > aimAssistFov) continue;
            double score = yawDelta + dist*2.0; if (score < bestScore) { bestScore = score; best = t; }
        }
        if (best == null) return;
        Vector3d eyes = p.getEyePosition(1.0f), target = best.getBoundingBox().getCenter();
        double dx=target.x-eyes.x, dy=target.y-eyes.y, dz=target.z-eyes.z, xz=Math.sqrt(dx*dx+dz*dz);
        float targetYaw=(float)(MathHelper.atan2(dz,dx)*(180f/Math.PI))-90f, targetPitch=(float)(-(MathHelper.atan2(dy,xz)*(180f/Math.PI)));
        p.yRot = approachAngle(p.yRot, targetYaw, aimAssistStrength);
        p.xRot = MathHelper.clamp(approachAngle(p.xRot, targetPitch, aimAssistStrength), -90f, 90f);
    }

    private static float approachAngle(float c, float t, float s) { float d=MathHelper.wrapDegrees(t-c); if(d>s)d=s; if(d<-s)d=-s; return c+d; }

    @SubscribeEvent
    public void onRenderLast(RenderWorldLastEvent e) {
        if (!jumpCirclesEnabled || CIRCLES.isEmpty()) return; Minecraft mc = Minecraft.getInstance(); if (mc.player==null||mc.level==null) return;
        ActiveRenderInfo cam = mc.gameRenderer.getMainCamera(); MatrixStack st = e.getMatrixStack();
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); RenderSystem.disableCull(); RenderSystem.disableDepthTest(); RenderSystem.depthMask(false);
        for (JumpCircle c : CIRCLES) {
            mc.getTextureManager().bind(STYLES[c.style]); Tessellator t=Tessellator.getInstance(); BufferBuilder b=t.getBuilder(); b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
            float lt=c.age/(float)c.maxLife, sf=lt<0.15f?lt/0.15f:(lt>0.80f?(1f-lt)/0.20f:1f), a=MathHelper.clamp(lt>0.80f?(1f-lt)/0.20f:1f,0f,1f); sf=MathHelper.clamp(sf,0f,1f);
            RenderSystem.color4f(1f,1f,1f,jumpEaseAlpha?a*a:a);
            float x=(float)(MathHelper.lerp(e.getPartialTicks(),c.prevX,c.x)-cam.getPosition().x), y=(float)(MathHelper.lerp(e.getPartialTicks(),c.prevY,c.y)-cam.getPosition().y), z=(float)(MathHelper.lerp(e.getPartialTicks(),c.prevZ,c.z)-cam.getPosition().z), s=c.targetScale*sf;
            st.pushPose(); st.translate(x,y,z); st.mulPose(Vector3f.XP.rotationDegrees(90f)); st.mulPose(Vector3f.ZP.rotationDegrees(c.rotation)); Matrix4f m=st.last().pose();
            b.vertex(m,-s,-s,0).uv(0,0).endVertex(); b.vertex(m,+s,-s,0).uv(1,0).endVertex(); b.vertex(m,+s,+s,0).uv(1,1).endVertex(); b.vertex(m,-s,+s,0).uv(0,1).endVertex(); st.popPose(); t.end();
        }
        RenderSystem.enableDepthTest(); RenderSystem.depthMask(true); RenderSystem.enableCull(); RenderSystem.disableBlend(); RenderSystem.color4f(1f,1f,1f,1f);
    }

    public static void startBindCapture(BindAction action) { pendingBind = action; }
    public static void captureBind(int key) { if (pendingBind != null) { BINDS.put(pendingBind, key); pendingBind = null; } }
    public static boolean isAwaitingBind() { return pendingBind != null; }
    public static String getBindName(BindAction action) { int k = BINDS.get(action); String n = GLFW.glfwGetKeyName(k, 0); return n != null ? n.toUpperCase() : (k==GLFW.GLFW_KEY_UNKNOWN?"NONE":"KEY "+k); }

    public static boolean isJumpCirclesEnabled() { return jumpCirclesEnabled; } public static void setJumpCirclesEnabled(boolean v) { jumpCirclesEnabled=v; }
    public static boolean isAutoSprintEnabled() { return autoSprintEnabled; } public static void setAutoSprintEnabled(boolean v) { autoSprintEnabled=v; }
    public static boolean isAimAssistEnabled() { return aimAssistEnabled; } public static void setAimAssistEnabled(boolean v) { aimAssistEnabled=v; }
    public static boolean isJumpResetEnabled() { return jumpResetEnabled; } public static void setJumpResetEnabled(boolean v) { jumpResetEnabled=v; }
    public static float getAimAssistRange() { return aimAssistRange; } public static void setAimAssistRange(float v) { aimAssistRange=MathHelper.clamp(v,2.5f,6f); }
    public static float getAimAssistFov() { return aimAssistFov; } public static void setAimAssistFov(float v) { aimAssistFov=MathHelper.clamp(v,10f,90f); }
    public static float getAimAssistStrength() { return aimAssistStrength; } public static void setAimAssistStrength(float v) { aimAssistStrength=MathHelper.clamp(v,1f,8f); }

    public static void cycleStyle() { jumpStyle=(jumpStyle+1)%STYLES.length; }
    public static String getJumpStyleName() { return "Style " + (jumpStyle+1); }
    public static float getJumpScale() { return jumpScale; } public static int getJumpLife() { return jumpLife; }
    public static void setJumpScale(float v) { jumpScale=MathHelper.clamp(v,0.5f,4f); } public static void setJumpLife(int v) { jumpLife=MathHelper.clamp(v,40,240); }
    public static void setJumpSpin(float v) { jumpSpinSpeed=MathHelper.clamp(v,0f,4f); } public static float getJumpSpinSpeed() { return jumpSpinSpeed; }
    public static boolean isJumpRandomStyle() { return jumpRandomStyle; } public static void setJumpRandomStyle(boolean r) { jumpRandomStyle=r; }
    public static boolean isJumpEaseAlpha() { return jumpEaseAlpha; } public static void setJumpEaseAlpha(boolean e) { jumpEaseAlpha=e; }

    private static class JumpCircle { double x,y,z,prevX,prevY,prevZ; float targetScale,rotation,spinSpeed; int age,maxLife,style;
        JumpCircle(double x,double y,double z,float ts,int life,int style,float ss){this.x=x;this.y=y;this.z=z;prevX=x;prevY=y;prevZ=z;targetScale=ts;maxLife=life;this.style=style;spinSpeed=ss;rotation=RNG.nextFloat()*360f;}
        void tick(){prevX=x;prevY=y;prevZ=z;rotation+=spinSpeed;age++;}}
}
