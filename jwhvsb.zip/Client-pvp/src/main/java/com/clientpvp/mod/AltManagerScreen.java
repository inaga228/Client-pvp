package com.clientpvp.mod;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.Session;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;


public class AltManagerScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget nickField;
    private String status = "Type nickname and click Login";

    protected AltManagerScreen(Screen parent) {
        super(new StringTextComponent("Alt Manager"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        this.nickField = new TextFieldWidget(this.font, cx - 110, this.height / 2 - 30, 220, 20, new StringTextComponent("Nickname"));
        this.nickField.setMaxLength(16);
        this.children.add(this.nickField);
        this.setInitialFocus(this.nickField);

        addButton(new Button(cx - 110, this.height / 2, 220, 20, new StringTextComponent("Login Offline"), b -> loginOffline()));
        addButton(new Button(cx - 110, this.height / 2 + 24, 220, 20, new StringTextComponent("Back"), b -> this.minecraft.setScreen(parent)));
    }

    private void loginOffline() {
        String nick = nickField.getValue().trim();
        if (nick.length() < 3) { status = "Nickname too short"; return; }
        try {
            Session session = new Session(nick, "", "", "legacy");
            ObfuscationReflectionHelper.setPrivateValue(Minecraft.class, Minecraft.getInstance(), session, "field_71449_j");
            status = "Logged as: " + nick;
        } catch (Exception e) {
            status = "Failed: " + e.getClass().getSimpleName();
        }
    }

    @Override
    public void tick() {
        super.tick();
        nickField.tick();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.nickField.keyPressed(keyCode, scanCode, modifiers) || this.nickField.canConsumeInput()) return true;
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (this.nickField.charTyped(codePoint, modifiers)) return true;
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public void render(MatrixStack stack, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(stack);
        drawCenteredString(stack, this.font, "Alt Manager", this.width / 2, this.height / 2 - 60, 0x77E6FF);
        this.nickField.render(stack, mouseX, mouseY, partialTicks);
        drawCenteredString(stack, this.font, status, this.width / 2, this.height / 2 + 52, 0xD0D7E2);
        super.render(stack, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
