package com.clientpvp.mod;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;

public class BindManagerScreen extends Screen {
    private final Screen parent;

    protected BindManagerScreen(Screen parent) {
        super(new StringTextComponent("Bind Manager"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 120;
        int y = this.height / 2 - 78;
        addButton(new Button(left, y, 240, 20, new StringTextComponent("Open GUI: " + ModController.getBindName(ModController.BindAction.OPEN_GUI)), b -> ModController.startBindCapture(ModController.BindAction.OPEN_GUI)));
        addButton(new Button(left, y + 24, 240, 20, new StringTextComponent("Jump Circles: " + ModController.getBindName(ModController.BindAction.TOGGLE_JUMP_CIRCLES)), b -> ModController.startBindCapture(ModController.BindAction.TOGGLE_JUMP_CIRCLES)));
        addButton(new Button(left, y + 48, 240, 20, new StringTextComponent("AutoSprint: " + ModController.getBindName(ModController.BindAction.TOGGLE_AUTOSPRINT)), b -> ModController.startBindCapture(ModController.BindAction.TOGGLE_AUTOSPRINT)));
        addButton(new Button(left, y + 72, 240, 20, new StringTextComponent("AimAssist: " + ModController.getBindName(ModController.BindAction.TOGGLE_AIMASSIST)), b -> ModController.startBindCapture(ModController.BindAction.TOGGLE_AIMASSIST)));
        addButton(new Button(left, y + 96, 240, 20, new StringTextComponent("JumpReset: " + ModController.getBindName(ModController.BindAction.TOGGLE_JUMPRESET)), b -> ModController.startBindCapture(ModController.BindAction.TOGGLE_JUMPRESET)));
        addButton(new Button(left, y + 124, 240, 20, new StringTextComponent("Back"), b -> minecraft.setScreen(parent)));
    }

    @Override
    public void tick() {
        super.tick();
        this.buttons.forEach(b -> {
            if (b.getMessage().getString().startsWith("Open GUI:")) b.setMessage(new StringTextComponent("Open GUI: " + ModController.getBindName(ModController.BindAction.OPEN_GUI)));
            if (b.getMessage().getString().startsWith("Jump Circles:")) b.setMessage(new StringTextComponent("Jump Circles: " + ModController.getBindName(ModController.BindAction.TOGGLE_JUMP_CIRCLES)));
            if (b.getMessage().getString().startsWith("AutoSprint:")) b.setMessage(new StringTextComponent("AutoSprint: " + ModController.getBindName(ModController.BindAction.TOGGLE_AUTOSPRINT)));
            if (b.getMessage().getString().startsWith("AimAssist:")) b.setMessage(new StringTextComponent("AimAssist: " + ModController.getBindName(ModController.BindAction.TOGGLE_AIMASSIST)));
            if (b.getMessage().getString().startsWith("JumpReset:")) b.setMessage(new StringTextComponent("JumpReset: " + ModController.getBindName(ModController.BindAction.TOGGLE_JUMPRESET)));
        });
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ModController.isAwaitingBind()) {
            ModController.captureBind(keyCode);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(MatrixStack stack, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(stack);
        int left = this.width / 2 - 130;
        int top = this.height / 2 - 90;
        fill(stack, left, top, left + 260, top + 180, 0xD0101010);
        drawCenteredString(stack, this.font, "Bind Manager", this.width / 2, top + 8, 0x77E6FF);
        if (ModController.isAwaitingBind()) drawCenteredString(stack, this.font, "Press any key...", this.width / 2, top + 22, 0xFFE083);
        super.render(stack, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
