package com.clientpvp.mod;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;

@Mod(ClientPvpMod.MOD_ID)
public class ClientPvpMod {
    public static final String MOD_ID = "clientpvpmod";

    public ClientPvpMod() {
        DistExecutor.safeRunWhenOn(Dist.CLIENT, () -> ClientInit::init);
    }

    private static class ClientInit {
        private static void init() {
            MinecraftForge.EVENT_BUS.register(new ModController());
        }
    }
}
