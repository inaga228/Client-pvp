package com.clientpvp.mod;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.text.StringTextComponent;

public class ClickGuiScreen extends Screen {
    private int panelX, panelY, panelW, panelH;
    public ClickGuiScreen() { super(new StringTextComponent("ClientPVP ClickGUI")); }

    @Override protected void init() { panelW = 320; panelH = 170; panelX = (this.width - panelW) / 2; panelY = (this.height - panelH) / 2; }
    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(MatrixStack s, int mx, int my, float pt) {
        renderBackground(s);
        fill(s, panelX, panelY, panelX + panelW, panelY + panelH, 0xD0101010);
        fill(s, panelX, panelY, panelX + panelW, panelY + 18, 0xD0202A32);
        drawCenteredString(s, font, "ClientPVP Panel", panelX + panelW / 2, panelY + 5, 0x77E6FF);
        drawRow(s, 0, mx, my, "Jump Circles", ModController.isJumpCirclesEnabled());
        drawRow(s, 1, mx, my, "AutoSprint", ModController.isAutoSprintEnabled());
        drawRow(s, 2, mx, my, "AimAssist", ModController.isAimAssistEnabled());
        drawRow(s, 3, mx, my, "JumpReset", ModController.isJumpResetEnabled());
        drawString(s, font, "RMB JumpCircles = settings", panelX + 12, panelY + 142, 0x9FAEC1);
        super.render(s, mx, my, pt);
    }

    private void drawRow(MatrixStack s, int idx, int mx, int my, String label, boolean state) {
        int y1 = panelY + 30 + idx * 24, y2 = y1 + 20;
        boolean h = mx >= panelX + 10 && mx <= panelX + panelW - 10 && my >= y1 && my <= y2;
        fill(s, panelX + 10, y1, panelX + panelW - 10, y2, h ? 0xAA2A343E : 0xAA1A222A);
        drawString(s, font, label + ": " + (state ? "ON" : "OFF"), panelX + 16, y1 + 6, 0xFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = 0; i < 4; i++) {
            int y1 = panelY + 30 + i * 24, y2 = y1 + 20;
            boolean h = mx >= panelX + 10 && mx <= panelX + panelW - 10 && my >= y1 && my <= y2;
            if (!h) continue;
            if (button == 0) {
                if (i == 0) ModController.setJumpCirclesEnabled(!ModController.isJumpCirclesEnabled());
                if (i == 1) ModController.setAutoSprintEnabled(!ModController.isAutoSprintEnabled());
                if (i == 2) ModController.setAimAssistEnabled(!ModController.isAimAssistEnabled());
                if (i == 3) ModController.setJumpResetEnabled(!ModController.isJumpResetEnabled());
                return true;
            }
            if (button == 1 && i == 0) { this.minecraft.setScreen(new JumpCircleSettingsScreen(this)); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }
}
